# Rotting Grief – Dialogue Freeze Fix

Unofficial fix for **Rotting Grief** (Steam) when the dialogue freezes right after the first line.

🇫🇷 [Version française plus bas](#-français)

## The problem

On Windows systems whose region uses a **decimal comma** (French, German, Spanish, Italian, Russian, Portuguese, Polish, Turkish…), the first dialogue line appears and then the game stops responding.

`Player.log` shows:

```
Setting Active Scene: Prologue_Bar
FormatException: Input string was not in a correct format.
  at System.Single.Parse (System.String s)
  at DialogueManager+<PlaySentence>d__20.MoveNext ()
```

`float.Parse()` uses the current Windows culture, so a value like `"0.05"` fails to parse, the dialogue coroutine dies, and the game softlocks. It has nothing to do with your CPU or GPU.

## Install

1. In Steam: right-click **Rotting Grief** → **Manage** → **Browse local files**.
2. Copy `INSTALLER_CORRECTIF.bat` and `RottingGriefFix.cs` into that folder, next to `Rotting Grief.exe`.
3. Double-click `INSTALLER_CORRECTIF.bat`. If SmartScreen appears: **More info** → **Run anyway**.
4. Launch the game from Steam as usual.

**Uninstall:** delete `winhttp.dll` from the game folder.

### No-mod alternatives

- **Windows:** `Win+R` → `intl.cpl` → Format: **English (United States)** → OK, then relaunch the game.
- **Steam Deck / Linux (Proton):** add `LC_ALL=C %command%` to the game's launch options.

## How it works

The installer:

1. Compiles `RottingGriefFix.cs` into `RottingGriefFix.dll` using the C# compiler that ships with Windows (`csc.exe` from .NET Framework 4).
2. Downloads [Unity Doorstop](https://github.com/NeighTools/UnityDoorstop) 4.6.0 (open-source mod loader) and copies its x64 `winhttp.dll` into the game folder.
3. Writes `doorstop_config.ini` so Doorstop loads the mod at startup.

The mod sets `CultureInfo.InvariantCulture` as the default culture before the game's code runs, so numbers are always parsed with a dot. Nothing else on your PC is changed.

## For the developer

In `DialogueManager.PlaySentence` (and anywhere else numbers are parsed from text), use:

```csharp
float.Parse(value, System.Globalization.CultureInfo.InvariantCulture)
```

To reproduce: set **Windows → Region → Format** to **French (France)**, then start a new game.

---

## 🇫🇷 Français

### Le problème

Sur un Windows en français (ou dans une autre langue qui utilise la virgule décimale), la première réplique s'affiche puis le jeu reste bloqué. Le jeu lit des nombres comme `"0.05"` selon la région de Windows. Avec une virgule, la lecture échoue (`FormatException` dans `DialogueManager.PlaySentence`) et le dialogue se fige. Le processeur et la carte graphique n'y sont pour rien.

### Installation

1. Dans Steam : clic droit sur **Rotting Grief** → **Gérer** → **Parcourir les fichiers locaux**.
2. Copie `INSTALLER_CORRECTIF.bat` et `RottingGriefFix.cs` dans ce dossier, à côté de `Rotting Grief.exe`.
3. Double-clique sur `INSTALLER_CORRECTIF.bat`. Si Windows affiche « Windows a protégé votre ordinateur » : **Informations complémentaires** → **Exécuter quand même**.
4. Lance le jeu depuis Steam.

**Désinstaller :** supprime `winhttp.dll` dans le dossier du jeu.

### Sans mod

- **Windows :** `Win+R` → `intl.cpl` → Format : **Anglais (États-Unis)** → OK, puis relance le jeu.
- **Steam Deck / Linux :** ajoute `LC_ALL=C %command%` dans les options de lancement du jeu.

---

## Credits

- Fix made with the help of Claude (Anthropic).
- [Unity Doorstop](https://github.com/NeighTools/UnityDoorstop) by NeighTools (LGPL-2.1), downloaded at install time and not included in this repository.

Unofficial fix, not affiliated with Spookily Games.
