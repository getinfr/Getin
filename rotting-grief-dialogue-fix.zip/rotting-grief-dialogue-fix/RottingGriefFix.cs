// Rotting Grief - correctif des dialogues bloques
// Le jeu lit ses nombres (ex: "0.05") avec float.Parse() sans preciser la culture.
// Sur un Windows en francais, le separateur decimal est la virgule -> FormatException
// dans DialogueManager.PlaySentence et le dialogue se fige.
// Ce mod force la culture "invariante" (point decimal) avant le demarrage du jeu.
using System.Globalization;
using System.Threading;

namespace Doorstop
{
    public static class Entrypoint
    {
        public static void Start()
        {
            CultureInfo c = CultureInfo.InvariantCulture;
            CultureInfo.DefaultThreadCurrentCulture = c;
            CultureInfo.DefaultThreadCurrentUICulture = c;
            Thread.CurrentThread.CurrentCulture = c;
            Thread.CurrentThread.CurrentUICulture = c;
        }
    }
}
