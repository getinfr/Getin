@echo off
setlocal
title Correctif Rotting Grief
cd /d "%~dp0"

if not exist "Rotting Grief.exe" (
  echo [ERREUR] Ce fichier doit etre dans le dossier du jeu, a cote de "Rotting Grief.exe".
  echo [ERROR] Put this file in the game folder, next to "Rotting Grief.exe".
  pause
  exit /b 1
)

echo [1/3] Compilation du mod / Building the mod...
set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" (
  echo [ERREUR] Compilateur C# de Windows introuvable.
  pause
  exit /b 1
)
"%CSC%" /nologo /target:library /optimize+ /out:RottingGriefFix.dll RottingGriefFix.cs
if errorlevel 1 (
  echo [ERREUR] La compilation a echoue.
  pause
  exit /b 1
)

echo [2/3] Telechargement / Downloading Unity Doorstop 4.6.0...
set "TMPDIR=%TEMP%\rg_doorstop"
if exist "%TMPDIR%" rd /s /q "%TMPDIR%"
mkdir "%TMPDIR%"
curl -L --fail -s -o "%TMPDIR%\doorstop.zip" https://github.com/NeighTools/UnityDoorstop/releases/download/v4.6.0/doorstop_win_release_4.6.0.zip
if errorlevel 1 (
  echo [ERREUR] Telechargement impossible. Verifie ta connexion internet.
  pause
  exit /b 1
)
tar -xf "%TMPDIR%\doorstop.zip" -C "%TMPDIR%"
set "FOUND="
for /f "delims=" %%f in ('dir /s /b "%TMPDIR%\winhttp.dll" ^| findstr /i "x64"') do (
  copy /y "%%f" "winhttp.dll" >nul
  set "FOUND=1"
)
if not defined FOUND (
  echo [ERREUR] winhttp.dll introuvable dans l'archive.
  pause
  exit /b 1
)
rd /s /q "%TMPDIR%"

echo [3/3] Configuration...
(
  echo [General]
  echo enabled = true
  echo target_assembly = RottingGriefFix.dll
  echo redirect_output_log = false
  echo boot_config_override =
  echo ignore_disable_switch = false
  echo.
  echo [UnityMono]
  echo dll_search_path_override =
  echo debug_enabled = false
  echo debug_address = 127.0.0.1:10000
  echo debug_suspend = false
) > doorstop_config.ini

echo.
echo ===========================================
echo  Correctif installe ! Lance le jeu depuis Steam.
echo  Fix installed! Launch the game from Steam.
echo  Pour le retirer / To remove: delete winhttp.dll
echo ===========================================
pause
